
        document.getElementById('announceForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const title = document.getElementById('title').value;
            const description = document.getElementById('description').value;
            const color = document.getElementById('color').value.replace('#','');
            const webhookUrl = 'https://discord.com/api/webhooks/1389273867503272077/ymwbFhXcY40C2-4Ko_6NO26izTSQQ2EKYjtshOcvnTJn3PaSNWrm0yAeIhE_e7KMRKrS';

            const data = {
                embeds: [{
                    title: title,
                    description: description,
                    color: parseInt(color, 16)
                }]
            };

            try {
                const res = await fetch(webhookUrl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(data)
                });
                if (res.ok) {
                    document.getElementById('responseMsg').textContent = 'Erfolgreich gesendet!';
                    document.getElementById('announceForm').reset();
                } else {
                    document.getElementById('responseMsg').textContent = 'Fehler beim Senden!';
                }
            } catch {
                document.getElementById('responseMsg').textContent = 'Fehler beim Senden!';
            }
        });