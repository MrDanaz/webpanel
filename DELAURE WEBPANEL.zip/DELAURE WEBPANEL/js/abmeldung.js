document.getElementById('logoutForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const discordId = document.getElementById('discordId').value.trim();
    const reason = document.getElementById('reason').value.trim();
    const datetime = document.getElementById('datetime').value;

    let dateStr = "";
    if (datetime) {
        const dt = new Date(datetime);
        const day = String(dt.getDate()).padStart(2, '0');
        const month = String(dt.getMonth() + 1).padStart(2, '0');
        const year = dt.getFullYear();
        const hours = String(dt.getHours()).padStart(2, '0');
        const minutes = String(dt.getMinutes()).padStart(2, '0');
        dateStr = `${day}.${month}.${year} ${hours}:${minutes}`;
    }

    const webhookUrl = "https://discord.com/api/webhooks/1389273867503272077/ymwbFhXcY40C2-4Ko_6NO26izTSQQ2EKYjtshOcvnTJn3PaSNWrm0yAeIhE_e7KMRKrS";
    const embed = {
        title: "",
        color: 16711680,
        description: `# TEAMLER ABMELDUNG\n### Name: <@${discordId}>\n### Grund: ${reason}\n### Datum & Uhrzeit: ${dateStr}`
    };

    try {
        const res = await fetch(webhookUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ embeds: [embed] })
        });
        if (res.ok) {
            document.getElementById('logoutMessage').textContent = "Abmeldung erfolgreich gesendet!";
            document.getElementById('logoutForm').reset();
        } else {
            document.getElementById('logoutMessage').textContent = "Fehler beim Senden. Bitte erneut versuchen.";
        }
    } catch {
        document.getElementById('logoutMessage').textContent = "Netzwerkfehler. Bitte erneut versuchen.";
    }
});
