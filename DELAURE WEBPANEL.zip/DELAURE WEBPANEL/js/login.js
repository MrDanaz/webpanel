                document.getElementById('loginForm').addEventListener('submit', function(e) {
                    e.preventDefault();
                    const username = document.getElementById('username').value;
                    const password = document.getElementById('password').value;
                    if (username === 'admin' && password === 'admin') {
                        window.location.href = 'home.html';
                    } else {
                        alert('Der Benutzername oder das Passwort ist falsch. Sollte es sich um einen Fehler handeln, bitte den Administrator kontaktieren.');
                    }
                });

                